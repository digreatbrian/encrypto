
Get to encrypt data easily using unique algorithm.Encrypto requires secret ,which is ,secret key/passcode to decrypt or encrypt data just in simple steps.
